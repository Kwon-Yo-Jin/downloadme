#ifndef MULTICORE_H
#define MULTICORE_H

#include <stdint.h>
#include <stddef.h>
#include <stdatomic.h>

typedef void (*fork_task_fn)(void *arg);

typedef struct {
    volatile _Atomic(uint32_t) hart_n;
    volatile _Atomic(uint32_t) run;      /* 0 = idle, 1 = task running */
    volatile _Atomic(uint32_t) done;
} pseudo_fork_task_t;

void set_pseudo_fork_hart(int);
uint32_t get_pseudo_fork_hart(void);

static inline void clint_send_ipi(int hart);
static inline void clint_clear_ipi(int hart);
static inline uint32_t clint_read_ipi(int hart);

void thread_entry(int, int);
uint32_t pseudo_fork(void);
void pseudo_fork_wait(void);
void pseudo_join(void);

#endif