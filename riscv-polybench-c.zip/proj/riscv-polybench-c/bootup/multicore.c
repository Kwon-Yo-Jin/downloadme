#include "multicore.h"
#include "encoding.h"

static pseudo_fork_task_t pseudo_fork_task __attribute__((aligned(16))) = {0};
static uint32_t context[32] __attribute__((aligned(16)));

void set_pseudo_fork_hart(int nc) {
    pseudo_fork_task.hart_n = nc;
    pseudo_fork_task.run = 0;
    pseudo_fork_task.done = 0;
}

uint32_t get_pseudo_fork_hart(void) {
    return pseudo_fork_task.hart_n;
}

static inline void clint_send_ipi(int hart)
{
    volatile register uint32_t *msip = (uint32_t *)(CLINT_BASE + 4 * hart);
    *msip = 1;
}

static inline void clint_clear_ipi(int hart)
{
    volatile register uint32_t *msip = (uint32_t *)(CLINT_BASE + 4 * hart);
    *msip = 0;
}

static inline uint32_t clint_read_ipi(int hart)
{
    volatile register uint32_t *msip = (uint32_t *)(CLINT_BASE + 4 * hart);
    return *msip;
}

void thread_entry(int cid, int nc) {
    if (cid) {
        set_csr(mie, MIP_MSIP);
        __asm__ volatile("wfi");
        pseudo_fork_wait();
    }
    else {
        for (int i = 0; i < 0x10000; i++) {
            __asm__ volatile("nop");
        }
        for (int i = 1; i <= MAX_HARTS_NUM; i++) {
            clint_send_ipi(i);
            __sync_synchronize();
            int alive = clint_read_ipi(i);
            if (alive) {
                clint_clear_ipi(i);
            }
            else {
                set_pseudo_fork_hart(i);
                break;
            }
        }
    }
}

void pseudo_fork_wait(void){
    __asm__ volatile("wfi");
    __sync_synchronize();
    if (!pseudo_fork_task.run) {
        __asm__ volatile(
            ".balign 4\n\t"
            "la t0, pseudo_fork_wait\n\t"
            "jalr x0, 0(t0)\n\t"
            :
            :
            : "t0"
        );
    }
    //fork_restore_context(context);
    __asm__ volatile(
        ".balign 4\n\t"
        "csrr t0, mhartid\n\t"
        "la sp, __stack_top\n\t"
        "slli t0, t0, 10\n\t"
        "sub sp, sp, t0\n\t"
        //"lw sp,  0(%0)\n\t"
        "lw ra,  4(%0)\n\t"
        "lw s0,  8(%0)\n\t"
        "lw s1,  12(%0)\n\t"
        "lw s2,  16(%0)\n\t"
        "lw s3,  20(%0)\n\t"
        "lw s4,  24(%0)\n\t"
        "lw s5,  28(%0)\n\t"
        "lw s6,  32(%0)\n\t"
        "lw s7,  36(%0)\n\t"
        "lw s8,  40(%0)\n\t"
        "lw s9,  44(%0)\n\t"
        "lw s10, 48(%0)\n\t"
        "lw s11, 52(%0)\n\t"

        "flw fs0,   56(%0)\n\t"
        "flw fs1,   60(%0)\n\t"
        "flw fs2,   64(%0)\n\t"
        "flw fs3,   68(%0)\n\t"
        "flw fs4,   72(%0)\n\t"
        "flw fs5,   76(%0)\n\t"
        "flw fs6,   80(%0)\n\t"
        "flw fs7,   84(%0)\n\t"
        "flw fs8,   88(%0)\n\t"
        "flw fs9,   92(%0)\n\t"
        "flw fs10,  96(%0)\n\t"
        "flw fs11, 100(%0)\n\t"
        "lw t0, 104(%0)\n\t"
        "fscsr t0\n\t"
        "la t0, jump_to_fork\n\t"
        "jalr x0, 0(t0)\n\t"
        :
        : "r"(context)
        : "t0", "ra", "s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9", "s10", "s11"
    );
    __builtin_unreachable();
}

void pseudo_join(void){
    __sync_fetch_and_add(&pseudo_fork_task.done, 1);
    //pseudo_fork_task.done ++;
    //while (pseudo_fork_task.done != pseudo_fork_task.hart_n);
    int me = read_csr(mhartid);
    if(me == 0) {
        //__sync_fetch_and_add(&pseudo_fork_task.done, 1);
        while(pseudo_fork_task.done != pseudo_fork_task.hart_n);
        pseudo_fork_task.run = 0;
        pseudo_fork_task.done = 0;
        __sync_synchronize();
        return;
    }
    clint_clear_ipi(me);
    //__asm__ volatile("fence iorw, iorw" ::: "memory");
    //__sync_fetch_and_add(&pseudo_fork_task.done, 1);
    __asm__ volatile(
        ".balign 4\n\t"
        "la t0, pseudo_fork_wait\n\t"
        "jalr x0, 0(t0)\n\t"
        :
        :
        : "t0"
    );
    __builtin_unreachable();
}

uint32_t pseudo_fork(void){
    pseudo_fork_task.run = 1;
    //fork_save_context(context);
    __asm__ volatile(
        ".balign 4\n\t"
        //"sw sp,  0(%0)\n\t"
        "sw ra,  4(%0)\n\t"
        "sw s0,  8(%0)\n\t"
        "sw s1,  12(%0)\n\t"
        "sw s2,  16(%0)\n\t"
        "sw s3,  20(%0)\n\t"
        "sw s4,  24(%0)\n\t"
        "sw s5,  28(%0)\n\t"
        "sw s6,  32(%0)\n\t"
        "sw s7,  36(%0)\n\t"
        "sw s8,  40(%0)\n\t"
        "sw s9,  44(%0)\n\t"
        "sw s10, 48(%0)\n\t"
        "sw s11, 52(%0)\n\t"
        "fsw fs0,   56(%0)\n\t"
        "fsw fs1,   60(%0)\n\t"
        "fsw fs2,   64(%0)\n\t"
        "fsw fs3,   68(%0)\n\t"
        "fsw fs4,   72(%0)\n\t"
        "fsw fs5,   76(%0)\n\t"
        "fsw fs6,   80(%0)\n\t"
        "fsw fs7,   84(%0)\n\t"
        "fsw fs8,   88(%0)\n\t"
        "fsw fs9,   92(%0)\n\t"
        "fsw fs10,  96(%0)\n\t"
        "fsw fs11, 100(%0)\n\t"
        "frcsr t0\n\t"
        "sw t0, 104(%0)\n\t"
        :
        : "r"(context)
        : "t0", "memory"
    );
    __sync_synchronize();
    int me = read_csr(mhartid);
    if (me == 0) {
        for (int i = 1; i < pseudo_fork_task.hart_n; i++){
            clint_send_ipi(i);
        }
    }
    __asm__ volatile(
        ".balign 4\n\t"
        ".global jump_to_fork\n\t"
        "jump_to_fork:\n\t"
    );
    return read_csr(mhartid);
}
