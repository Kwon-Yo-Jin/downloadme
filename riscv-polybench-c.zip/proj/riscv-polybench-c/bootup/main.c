/* Entry point for main.elf, statically linked with the selected benchmarks.
 * The Makefile generates benchmarks.def for this selection and gives each
 * benchmark a unique bench_<name> entry point, leaving its source unchanged.
 */
#include <stddef.h>
#include <stdio.h>

#include "multicore.h"

#define BENCHMARK(name, entry) extern int entry(int argc, char **argv);
#include "benchmarks.def"
#undef BENCHMARK

struct benchmark {
    const char *name;
    int (*run)(int argc, char **argv);
};

static const struct benchmark benchmarks[] = {
#define BENCHMARK(name, entry) {name, entry},
#include "benchmarks.def"
#undef BENCHMARK
};

int main(int argc, char **argv)
{
    static volatile int sum = 0;
    const int inner_loop = 4;
    const int outer_loop = 4;
    for(int i = 0; i < outer_loop; i ++) {
        pseudo_fork();
        for (int j = 0; j < inner_loop; j++) {
            sum ++;
        }
        pseudo_join();
    }
    printf("%d hart(s) alive\n", sum / inner_loop / outer_loop);
    for (size_t i = 0; i < sizeof(benchmarks) / sizeof(benchmarks[0]); ++i) {
        printf("Benchmark: %s\n", benchmarks[i].name);
        /* Preserve the arguments used by PolyBench's dead-code-elimination
         * guard while the shared runtime stays active for the whole suite.
         */
        int status = benchmarks[i].run(argc, argv);
        if (status != 0) {
            fprintf(stderr, "Benchmark %s failed with status %d\n",
                    benchmarks[i].name, status);
            return status;
        }
    }
    return 0;
}
