/* Bare-metal newlib support for single-hart Spike execution.
 * Console I/O uses the built-in NS16550 UART; HTIF is used only to exit.
 * Exit protocol adapted from coremark/riscv32-baremetal/syscalls.c.
 * See LICENSE for the original code's license.
 */
#include <errno.h>
#include <malloc.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

extern volatile uint64_t tohost;
extern char __heap_start[], __heap_end[];
extern int main(int argc, char **argv);
extern void __libc_init_array(void);

/* Spike's default DTB: NS16550 at 0x10000000, byte-wide registers. */
#ifndef UART_BASE
#define UART_BASE 0x10000000UL
#endif
#define UART_RBR_THR 0
#define UART_IER     1
#define UART_FCR     2
#define UART_LCR     3
#define UART_LSR     5
#define UART_LSR_DR   0x01
#define UART_LSR_THRE 0x20
#define UART_LSR_TEMT 0x40
#define UART_REG(offset) (*(volatile uint8_t *)(UART_BASE + (offset)))

static void uart_init(void)
{
  UART_REG(UART_LCR) = 0x03; /* 8 data bits, no parity, one stop bit; DLAB off. */
  UART_REG(UART_IER) = 0;    /* Polled I/O, no UART interrupts. */
  UART_REG(UART_FCR) = 0x07; /* Enable FIFO and clear receive/transmit queues. */
  __asm__ volatile ("fence iorw, iorw" ::: "memory");
}

ssize_t _write(int fd, const void *buffer, size_t length)
{
  if (fd != STDOUT_FILENO && fd != STDERR_FILENO) {
    errno = EBADF;
    return -1;
  }
  const uint8_t *bytes = buffer;
  for (size_t i = 0; i < length; ++i) {
    while (!(UART_REG(UART_LSR) & UART_LSR_THRE))
      ;
    UART_REG(UART_RBR_THR) = bytes[i];
    __asm__ volatile ("fence iorw, iorw" ::: "memory");
  }
  return length;
}

void _exit(int status) __attribute__((noreturn));
void _exit(int status)
{
  /* Finish UART transmission before notifying Spike that execution is done. */
  while (!(UART_REG(UART_LSR) & UART_LSR_TEMT))
    ;
  __asm__ volatile ("fence iorw, iorw" ::: "memory");
  tohost = ((uint64_t)(unsigned int)status << 1) | 1;
  for (;;)
    __asm__ volatile ("wfi");
}

void *_sbrk(ptrdiff_t increment)
{
  static uintptr_t current = (uintptr_t)__heap_start;
  uintptr_t previous = current;

  if (increment >= 0) {
    if ((uintptr_t)increment > (uintptr_t)__heap_end - current) {
      errno = ENOMEM;
      return (void *)-1;
    }
    current += (uintptr_t)increment;
  } else {
    uintptr_t decrease = (uintptr_t)(-(increment + 1)) + 1;
    if (decrease > current - (uintptr_t)__heap_start) {
      errno = ENOMEM;
      return (void *)-1;
    }
    current -= decrease;
  }
  return (void *)previous;
}

/* This newlib build provides memalign but not the POSIX allocation entry point
 * used by PolyBench. POSIX returns the error number and preserves errno. */
int posix_memalign(void **result, size_t alignment, size_t size)
{
  if (alignment < sizeof(void *) || (alignment & (alignment - 1)) != 0)
    return EINVAL;

  int saved_errno = errno;
  void *allocation = memalign(alignment, size);
  errno = saved_errno;
  if (allocation == NULL)
    return ENOMEM;
  *result = allocation;
  return 0;
}

int _fstat(int fd, struct stat *status)
{
  if (fd < STDIN_FILENO || fd > STDERR_FILENO) {
    errno = EBADF;
    return -1;
  }
  *status = (struct stat){0};
  status->st_mode = S_IFCHR;
  return 0;
}

int _isatty(int fd)
{
  if (fd >= STDIN_FILENO && fd <= STDERR_FILENO)
    return 1;
  errno = EBADF;
  return 0;
}

int _close(int fd)
{
  if (fd >= STDIN_FILENO && fd <= STDERR_FILENO)
    return 0;
  errno = EBADF;
  return -1;
}

off_t _lseek(int fd, off_t offset, int whence)
{
  (void)fd;
  (void)offset;
  (void)whence;
  errno = ESPIPE;
  return -1;
}

ssize_t _read(int fd, void *buffer, size_t length)
{
  if (fd != STDIN_FILENO) {
    errno = EBADF;
    return -1;
  }
  if (length == 0)
    return 0;
  while (!(UART_REG(UART_LSR) & UART_LSR_DR))
    ;
  uint8_t *bytes = buffer;
  size_t count = 0;
  do {
    bytes[count++] = UART_REG(UART_RBR_THR);
    __asm__ volatile ("fence iorw, iorw" ::: "memory");
  } while (count < length && (UART_REG(UART_LSR) & UART_LSR_DR));
  return count;
}

int _getpid(void)
{
  return 1;
}

int _kill(int pid, int signal)
{
  (void)pid;
  (void)signal;
  errno = EINVAL;
  return -1;
}

/* Newlib invokes this hook from __libc_init_array. */
void _init(void)
{
}

void __attribute__((weak)) thread_entry(int cid, int nc)
{
  // multi-threaded programs override this function.
  // for the case of single-threaded programs, only let core 0 proceed.
  while (cid != 0);
}

void boot_main(int cid, int nc) __attribute__((noreturn));
void boot_main(int cid, int nc)
{
  char program[] = "polybench";
  char *argv[] = {program, NULL};
  thread_entry(cid, nc);
  uart_init();
  __libc_init_array();
  exit(main(1, argv));
}

uintptr_t handle_trap(uintptr_t cause, uintptr_t pc, uintptr_t registers[32])
{
  (void)registers;
  fprintf(stderr, "Unhandled RISC-V trap: mcause=0x%lx mepc=0x%lx\n",
          (unsigned long)cause, (unsigned long)pc);
  _exit(128 + (int)(cause & 127));
}
