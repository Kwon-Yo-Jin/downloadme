# RV32 PolyBench/C

Build the 30 PolyBench/C 4.2.1 benchmarks as separate bare-metal RV32IMAFC
executables. Add `main` to also build a single executable whose shared `main()`
calls the selected benchmarks in sequence.

| Command | Executables built | Spike execution |
| --- | --- | --- |
| `make gemm` | `gemm.elf` | None |
| `make all` | All 30 benchmark ELFs | None |
| `make main gemm` | `gemm.elf` and `main.elf` | None |
| `make main all` | All 30 benchmark ELFs and `main.elf` | None |
| `make spike gemm` | `gemm.elf` | One standalone benchmark |
| `make spike all` | All 30 benchmark ELFs | 30 separate Spike invocations |
| `make spike main gemm` | `gemm.elf` and `main.elf` | One invocation of `main.elf`, calling GEMM |
| `make spike main all` | All 30 benchmark ELFs and `main.elf` | One invocation of `main.elf`, calling all 30 benchmarks |

Build commands print the requested ELF locations: one for `make gemm`, 30 for
`make all`, two for `make main gemm`, and 31 for `make main all`.
`make` alone is equivalent to `make all`. Use `make list` for benchmark names
and `make clean` to remove generated files.

Benchmark executables mirror the source directories beneath `build/`: for example,
`polybench-c-4.2.1-beta/linear-algebra/blas/gemm/gemm.c` produces
`build/linear-algebra/blas/gemm/gemm.elf`. The combined executable is
`build/main.elf`. Every ELF has a `.dump` disassembly and a linker `.map` alongside
it, including those built by Spike commands. A dump can also be requested directly,
for example `make build/linear-algebra/blas/gemm/gemm.dump`.

Standalone executables use each benchmark's original `main()`. For `main.elf`,
benchmark entry points are renamed at compilation to unique functions such as
`bench_gemm` and `bench_2mm`. Their object files are statically linked with the
shared `main()` in `bootup/main.c` and the bare-metal runtime; `main.elf` does not
load or launch the separate benchmark ELFs. No proxy kernel is needed.

The Makefile generates the selected benchmark list from
`polybench-c-4.2.1-beta/utilities/benchmark_list`, preserving its order.
Changing the selection rebuilds `main.elf` as needed: for example, `make main all`
after `make main gemm` links all 30 benchmark entry points into the combined
executable. The shared main passes `argc` and `argv` to each benchmark and stops
with its error status if a benchmark fails. A Spike command containing `main`
runs only `main.elf`; without `main`, it runs the selected standalone executables
separately. Multiple names are supported, for example:

```sh
make -j4 gemm atax           # build two standalone executables
make spike gemm atax         # run those executables separately
make spike main gemm atax    # run both benchmarks through one shared main()
```

The defaults are `DATASET=MEDIUM` and `DATA_TYPE=FLOAT`, which selects
single-precision floating point for all benchmarks. Select other sizes or types
on the command line:

```sh
make all DATASET=LARGE
make spike gemm DATASET=SMALL DATA_TYPE=FLOAT
make spike gemm DUMP_ARRAYS=1
```

`DATASET` accepts `MINI`, `SMALL`, `MEDIUM`, `LARGE`, or `EXTRALARGE`.
`DATA_TYPE` accepts `DEFAULT`, `FLOAT`, or `DOUBLE`. `DEFAULT` preserves each
benchmark's upstream numeric type; `FLOAT` and `DOUBLE` override all selected
kernels, including those that normally use integers. RV32IMAFC
has hardware single-precision floating point; double-precision operations use
software helpers. Changed build options automatically trigger rebuilding.

Spike runs identify the selected benchmarks, and the shared main prints
`Benchmark: <name>` before each call. Each benchmark prints its elapsed `mcycle`
count as a decimal integer. Allocation, initialization, and the benchmark label
are outside the timed region. Cache flushing is disabled. Spike is an ISA simulator:
its cycle counts are not hardware timing predictions. `DUMP_ARRAYS=1` also prints the resulting arrays for validation;
this is separate from the `.dump` disassembly files.

The Makefile defaults to these supplied tools:

- GCC: `/proj/riscv-gnu-toolchain/rv32imafc/bin/riscv32-unknown-elf-gcc`
- Spike: `/proj/riscv-rebuild/chipyard/.conda-env/riscv-tools/bin/spike`

Override `TOOLCHAIN`, `CROSS_COMPILE`, `CC`, `OBJDUMP`, or `SPIKE` to use another
location. Disassembly uses the toolchain's RISC-V `objdump` with
`OBJDUMPFLAGS=-d` by default; override `OBJDUMPFLAGS` to change its options.
`CFLAGS`, `CPPFLAGS`, `LDFLAGS`, `LDLIBS`, `ARCH`, `ABI`, `SPIKE_ISA`, and
`SPIKE_FLAGS` are also configurable. The supplied libraries use `ilp32f`.
The default architecture includes `zicsr` explicitly for startup and counter
instructions. Spike runs one hart with 256 MiB of RAM to match the linker
layout at `0x80000000`.

Console input and output use Spike's built-in NS16550 UART at `0x10000000`.
Newlib formats `printf` on the target, and `_write()` polls the UART transmitter
and writes each byte to its MMIO register. `_read()` polls the UART receiver.
Startup configures 8 data bits, no parity, one stop bit, enabled FIFOs, and
disabled UART interrupts. The supplied Spike creates the UART from its default
device tree, so the existing `--isa=rv32imafc_zicsr -p1 -m256` arguments suffice;
no `--device` or `--bootargs` option is needed. Do not pass `--disable-dtb`, which
removes the UART; the Makefile rejects that flag for Spike runs.

HTIF is retained only for simulator termination: `_exit()` waits for UART output
to drain, then writes the exit status to `tohost`. Console traffic no longer
uses HTIF syscall requests or `fromhost` polling. On hardware, the UART address,
register layout, clock and baud-rate setup, and termination behavior must match
the platform; this runtime targets the supplied Spike configuration.

Startup files in `bootup/` were adapted from
`/proj/riscv-rebuild/software/coremark/riscv32-baremetal`; they provide startup,
UART console I/O, HTIF exit, and newlib heap/system-call support. The bundled PolyBench
utility timer has a small RISC-V adaptation for reading the complete 64-bit
`mcycle` counter on RV32. The heat-3d cleanup frees both allocated arrays so
later benchmarks can reuse the memory. Benchmark computations are unchanged.

## TODO

multicore