/**
 * This version is stamped on May 10, 2016
 *
 * Contact:
 *   Louis-Noel Pouchet <pouchet.ohio-state.edu>
 *   Tomofumi Yuki <tomofumi.yuki.fr>
 *
 * Web address: http://polybench.sourceforge.net
 */
/* gemm.c: this file is part of PolyBench/C */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include <polybench.h>

/* Include benchmark-specific header. */
#include "gemm.h"

#include "multicore.h"

typedef struct {
  uint32_t i_position;
  uint32_t j_position;
  float value;
  float should_be;
} gemm_error_t;

static gemm_error_t gemm_error;

/* Array initialization. */
static
void init_array(int ni, int nj, int nk,
    DATA_TYPE *alpha,
    DATA_TYPE *beta,
    DATA_TYPE POLYBENCH_2D(C,NI,NJ,ni,nj),
    DATA_TYPE POLYBENCH_2D(D,NI,NJ,ni,nj),
    DATA_TYPE POLYBENCH_2D(A,NI,NK,ni,nk),
    DATA_TYPE POLYBENCH_2D(B,NK,NJ,nk,nj))
{
  int i, j;

  *alpha = 1.5;
  *beta = 1.2;
  for (i = 0; i < ni; i++)
    for (j = 0; j < nj; j++) {
      C[i][j] = (DATA_TYPE) ((i*j+1) % ni) / ni;
      D[i][j] = C[i][j];
    }
  for (i = 0; i < ni; i++)
    for (j = 0; j < nk; j++)
      A[i][j] = (DATA_TYPE) (i*(j+1) % nk) / nk;
  for (i = 0; i < nk; i++)
    for (j = 0; j < nj; j++)
      B[i][j] = (DATA_TYPE) (i*(j+2) % nj) / nj;
}


/* DCE code. Must scan the entire live-out data.
   Can be used also to check the correctness of the output. */
static
void print_array(int ni, int nj,
     DATA_TYPE POLYBENCH_2D(C,NI,NJ,ni,nj))
{
  int i, j;

  POLYBENCH_DUMP_START;
  POLYBENCH_DUMP_BEGIN("C");
  for (i = 0; i < ni; i++)
    for (j = 0; j < nj; j++) {
      if ((i * ni + j) % 20 == 0) fprintf (POLYBENCH_DUMP_TARGET, "\n");
      fprintf (POLYBENCH_DUMP_TARGET, DATA_PRINTF_MODIFIER, C[i][j]);
    }
  POLYBENCH_DUMP_END("C");
  POLYBENCH_DUMP_FINISH;
}


/* Main computational kernel. The whole function will be timed,
   including the call and return. */
static
void kernel_gemm(int ni, int nj, int nk,
    DATA_TYPE alpha,
    DATA_TYPE beta,
    DATA_TYPE POLYBENCH_2D(C,NI,NJ,ni,nj),
    DATA_TYPE POLYBENCH_2D(A,NI,NK,ni,nk),
    DATA_TYPE POLYBENCH_2D(B,NK,NJ,nk,nj))
{
  int i, j, k;

//BLAS PARAMS
//TRANSA = 'N'
//TRANSB = 'N'
// => Form C := alpha*A*B + beta*C,
//A is NIxNK
//B is NKxNJ
//C is NIxNJ
#pragma scop
  for (i = 0; i < _PB_NI; i++) {
    for (j = 0; j < _PB_NJ; j++)
      C[i][j] *= beta;
    for (k = 0; k < _PB_NK; k++) {
      for (j = 0; j < _PB_NJ; j++)
        C[i][j] += alpha * A[i][k] * B[k][j];
    }
  }
#pragma endscop

}

static
void kernel_gemm_parallel(int ni, int nj, int nk,
    DATA_TYPE alpha,
    DATA_TYPE beta,
    DATA_TYPE POLYBENCH_2D(C,NI,NJ,ni,nj),
    DATA_TYPE POLYBENCH_2D(A,NI,NK,ni,nk),
    DATA_TYPE POLYBENCH_2D(B,NK,NJ,nk,nj))
{

//BLAS PARAMS
//TRANSA = 'N'
//TRANSB = 'N'
// => Form C := alpha*A*B + beta*C,
//A is NIxNK
//B is NKxNJ
//C is NIxNJ
#pragma scop
  int hart_id = pseudo_fork();
  unsigned int hart_num = get_pseudo_fork_hart();
  unsigned int tiling_i_factor = (uint32_t)sqrt((float)hart_num) + 1;
  unsigned int tiling_j_factor = hart_num / tiling_i_factor;
  while((tiling_i_factor * tiling_j_factor) < hart_num) {
    tiling_i_factor --;
    tiling_j_factor = hart_num / tiling_i_factor;
  }
  //printf("%d, %d\n", tiling_i_factor, tiling_j_factor);
  unsigned int tile_i = hart_id / tiling_j_factor;
  unsigned int tile_j = hart_id % tiling_j_factor;
  //printf("%d, %d\n", tile_i, tile_j);
  unsigned int i_interval = _PB_NI / tiling_i_factor + (_PB_NI % tiling_i_factor != 0);
  unsigned int i_begin = i_interval * tile_i;
  unsigned int i_end = i_begin + i_interval;
  if (i_end > _PB_NI) i_end = _PB_NI;
  //printf("%d, %d\n", i_begin, i_end);
  unsigned int j_interval = _PB_NJ / tiling_j_factor + (_PB_NJ % tiling_j_factor != 0);
  unsigned int j_begin = j_interval * tile_j;
  unsigned int j_end = j_begin + j_interval;
  if (j_end > _PB_NJ) j_end = _PB_NJ;
  //printf("%d, %d\n", j_begin, j_end);

  for (int i = i_begin; i < i_end; i++) {
    for (int j = j_begin; j < j_end; j++)
      C[i][j] *= beta;
    for (int k = 0; k < _PB_NK; k++) {
       for (int j = j_begin; j < j_end; j++)
        C[i][j] += alpha * A[i][k] * B[k][j];
    }
  }
  pseudo_join();
#pragma endscop

}

static
int kernel_gemm_verify(int ni, int nj, int nk,
     DATA_TYPE POLYBENCH_2D(C,NI,NJ,ni,nj),
     DATA_TYPE POLYBENCH_2D(D,NI,NJ,ni,nj))
{
  int i, j;
  for (i = 0; i < _PB_NI; i++) {
    for (j = 0; j < _PB_NJ; j++) {
      if (C[i][j] != D[i][j]) {
        gemm_error.i_position = i;
        gemm_error.j_position = j;
        gemm_error.value = C[i][j];
        gemm_error.should_be = D[i][j];
        return 1;
      }
    }
  }
  return 0;
}

int main(int argc, char** argv)
{
  /* Retrieve problem size. */
  int ni = NI;
  int nj = NJ;
  int nk = NK;

  /* Variable declaration/allocation. */
  DATA_TYPE alpha;
  DATA_TYPE beta;
  POLYBENCH_2D_ARRAY_DECL(C,DATA_TYPE,NI,NJ,ni,nj);
  POLYBENCH_2D_ARRAY_DECL(D,DATA_TYPE,NI,NJ,ni,nj);
  POLYBENCH_2D_ARRAY_DECL(A,DATA_TYPE,NI,NK,ni,nk);
  POLYBENCH_2D_ARRAY_DECL(B,DATA_TYPE,NK,NJ,nk,nj);

  /* Initialize array(s). */
  init_array (ni, nj, nk, &alpha, &beta,
        POLYBENCH_ARRAY(C),
        POLYBENCH_ARRAY(D),
        POLYBENCH_ARRAY(A),
        POLYBENCH_ARRAY(B));

  printf("Single thread:\n");

  /* Start timer. */
  polybench_start_instruments;

  /* Run kernel. */
  kernel_gemm (ni, nj, nk,
        alpha, beta,
        POLYBENCH_ARRAY(C),
        POLYBENCH_ARRAY(A),
        POLYBENCH_ARRAY(B));

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;


  printf("Parallel:\n");

  /* Start timer. */
  polybench_start_instruments;

  /* Run kernel. */
  kernel_gemm_parallel (ni, nj, nk,
        alpha, beta,
        POLYBENCH_ARRAY(D),
        POLYBENCH_ARRAY(A),
        POLYBENCH_ARRAY(B));

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  if (kernel_gemm_verify (ni, nj, nk,
        POLYBENCH_ARRAY(C),
        POLYBENCH_ARRAY(D))) {
          printf("Error: Parallel failed\n");
          printf("At %d, %d:\n", gemm_error.i_position, gemm_error.j_position);
          printf("\terror: %f\n", gemm_error.value);
          printf("\tshould be: %f\n", gemm_error.should_be);
        }
  else printf("Pass: parallel verification\n");

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print_array(ni, nj,  POLYBENCH_ARRAY(C)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(C);
  POLYBENCH_FREE_ARRAY(D);
  POLYBENCH_FREE_ARRAY(A);
  POLYBENCH_FREE_ARRAY(B);

  return 0;
}
