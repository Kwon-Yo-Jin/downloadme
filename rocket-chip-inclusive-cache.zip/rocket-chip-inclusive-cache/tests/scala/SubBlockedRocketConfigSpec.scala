package rocketnoc.test

import circt.stage.ChiselStage
import java.nio.file.Paths
import org.chipsalliance.cde.config.{Config, Parameters}
import org.scalatest.flatspec.AnyFlatSpec
import freechips.rocketchip.devices.tilelink.BootROMLocated
import freechips.rocketchip.diplomacy.{LazyModule, TransferSizes}
import freechips.rocketchip.rocket.WithNBigCores
import freechips.rocketchip.subsystem._
import freechips.rocketchip.system.{BaseConfig, ExampleRocketSystem}
import freechips.rocketchip.util.SystemFileName
import sifive.blocks.inclusivecache.InclusiveCache

/** Standard Rocket integration, with two banks to expose incorrect 16B banking.
  * The boot image is only needed for elaboration; no instructions execute here.
  */
class SubBlockedRocketConfigSpec extends AnyFlatSpec {
  behavior of "Sub-blocked InclusiveCache Rocket integration"

  it should "elaborate two Rocket cores with 16B L1 lines and two 64B L2 banks" in {
    val bootImage = Paths.get("rocket-chip", "bootrom", "bootrom.img").toAbsolutePath.toString
    val localBootROM = new Config((site, here, up) => {
      case BootROMLocated(InSubsystem) => up(BootROMLocated(InSubsystem), site).map {
        _.copy(contentFileName = SystemFileName(bootImage), appendDTB = false)
      }
    })
    implicit val p: Parameters = new Config(
      localBootROM ++
      new WithInclusiveCache(nWays = 2, capacityKB = 16, l2BlockBytes = Some(64)) ++
      new WithCacheBlockBytes(16) ++
      new WithNBanks(2) ++
      new WithNBigCores(2) ++
      new WithCoherentBusTopology ++
      new BaseConfig)

    assert(p(CacheBlockBytes) == 16)
    assert(p(SystemBusKey).blockBytes == 16)
    assert(p(MemoryBusKey).blockBytes == 64)
    assert(p(InclusiveCacheKey).sets == 64) // 16 KiB / (2 banks * 2 ways * 64B)
    assert(p(SystemBusKey).beatBytes == 8)
    assert(p(MemoryBusKey).beatBytes == 8)

    val system = LazyModule(new ExampleRocketSystem)
    val chirrtl = ChiselStage.emitCHIRRTL(system.module)
    assert(chirrtl.contains("module ICache"))
    assert(chirrtl.contains("module DCache"))
    assert(system.rocketTiles.size == 2)
    system.rocketTiles.foreach { tile =>
      assert(tile.rocketParams.icache.get.blockBytes == 16)
      assert(tile.rocketParams.dcache.get.blockBytes == 16)
      assert(tile.rocketParams.icache.get.rowBits == 64)
      assert(tile.rocketParams.dcache.get.rowBits == 64)
    }

    def descendants(module: LazyModule): Seq[LazyModule] =
      module +: module.getChildren.flatMap(descendants)
    val caches = descendants(system).collect { case cache: InclusiveCache => cache }
    assert(caches.size == 1)
    val cache = caches.head
    assert(cache.cache.blockBytes == 64)
    assert(cache.cache.coherenceBytes == 16)
    assert(cache.cache.nSubBlocks == 4)
    assert(cache.node.edges.in.size == 2)
    assert(cache.node.edges.out.size == 2)
    cache.node.edges.in.foreach { edge =>
      edge.manager.managers.foreach { manager =>
        assert(manager.supportsAcquireB == TransferSizes(16, 16))
      }
      edge.client.clients.filter(_.supports.probe).foreach { client =>
        assert(client.supports.probe == TransferSizes(16, 16))
      }
    }
    cache.node.edges.out.foreach { edge =>
      edge.manager.managers.foreach { manager =>
        assert(manager.supportsAcquireB.contains(TransferSizes(64, 64)))
        assert(manager.address.forall(_.alignment >= 64))
      }
    }
  }
}
