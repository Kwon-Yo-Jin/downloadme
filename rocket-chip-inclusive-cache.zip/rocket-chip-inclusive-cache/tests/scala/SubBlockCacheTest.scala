package rocketnoc.test

import chisel3._
import chisel3.util.log2Ceil
import chiseltest._
import chiseltest.simulator.VerilatorFlags
import org.chipsalliance.cde.config.Parameters
import org.scalatest.flatspec.AnyFlatSpec
import freechips.rocketchip.diplomacy._
import freechips.rocketchip.tilelink._
import sifive.blocks.inclusivecache._
import scala.collection.mutable
import scala.util.Random

/** Real cache and CacheCork, with both TileLink boundaries controlled by the test.
  * The memory boundary is TL-UL and the client boundary is TL-C. Monitors stay on.
  */
class SubBlockCacheHarness(val coherenceBytes: Int)(implicit p: Parameters) extends LazyModule {
  val client = TLClientNode(Seq(TLClientPortParameters(Seq(
    TLClientParameters(name = "test-core-0", sourceId = IdRange(0, 4),
      supportsProbe = TransferSizes(coherenceBytes, coherenceBytes)),
    TLClientParameters(name = "test-core-1", sourceId = IdRange(4, 8),
      supportsProbe = TransferSizes(coherenceBytes, coherenceBytes)),
    TLClientParameters(name = "test-uncached", sourceId = IdRange(8, 9))
  ))))
  val cache = LazyModule(new InclusiveCache(
    CacheParameters(level = 2, ways = 2, sets = 2, blockBytes = 64, beatBytes = 8,
      hintsSkipProbe = false, subBlockBytes = Some(coherenceBytes)),
    InclusiveCacheMicroParameters(writeBytes = 8, memCycles = 8)))
  val cork = LazyModule(new TLCacheCork)
  val memory = TLManagerNode(Seq(TLManagerPortParameters(Seq(
    TLManagerParameters(address = Seq(AddressSet(0, 0xffff)),
      regionType = RegionType.UNCACHED,
      supportsGet = TransferSizes(1, 64),
      supportsPutFull = TransferSizes(1, 64),
      supportsPutPartial = TransferSizes(1, 64))
  ), beatBytes = 8, minLatency = 1)))
  memory := cork.node := cache.node := client

  lazy val module = new SubBlockCacheHarnessImp(this)
}

class SubBlockCacheHarnessImp(outer: SubBlockCacheHarness) extends LazyModuleImp(outer) {
  val in = IO(Flipped(new TLBundle(outer.client.out.head._2.bundle)))
  val out = IO(new TLBundle(outer.memory.in.head._2.bundle))
  outer.client.out.head._1 <> in
  out <> outer.memory.in.head._1
}

class SubBlockCacheTest extends AnyFlatSpec with ChiselScalatestTester {
  private case class A(op: Int, param: Int, size: Int, source: Int, address: Int,
    data: BigInt = 0, mask: Int = 255)
  private case class C(op: Int, param: Int, source: Int, address: Int, data: BigInt,
    last: Boolean, due: Int)
  private case class D(op: Int, size: Int, source: Int, data: BigInt, due: Int)
  private case class Held(var permission: Int, data: Array[Int], var dirty: Boolean)
  private case class Request(op: Int, address: Int, size: Int, data: mutable.ArrayBuffer[Int])
  private case class MemoryOp(op: Int, address: Int, size: Int)

  private def exercise(coherenceBytes: Int): Unit = {
    implicit val p: Parameters = Parameters.empty
    val harness = LazyModule(new SubBlockCacheHarness(coherenceBytes))
    test(harness.module).withAnnotations(Seq(VerilatorBackendAnnotation,
      VerilatorFlags(Seq("-Wno-fatal")))) { dut =>
      dut.clock.setTimeout(30000)
      val random = new Random(0x1640)
      val lgCoherence = log2Ceil(coherenceBytes)
      val aQueue = mutable.Queue.empty[A]
      val cQueue = mutable.Queue.empty[C]
      val eQueue = mutable.Queue.empty[(Int, Int)]
      val dQueue = mutable.Queue.empty[D]
      val held = mutable.Map.empty[(Int, Int), Held]
      val pending = mutable.Map.empty[Int, Request]
      val results = mutable.Map.empty[Int, Vector[Int]]
      val releases = mutable.Set.empty[Int]
      val memory = mutable.Map.empty[Int, Int]
      val expected = mutable.Map.empty[Int, Int]
      val memoryOps = mutable.ArrayBuffer.empty[MemoryOp]
      val probes = mutable.ArrayBuffer.empty[(Int, Int)]
      val putBeat = mutable.Map.empty[Int, Int]
      var cycle = 0
      var releaseCount = 0
      var grantAckCount = 0
      var grantCount = 0
      var randomStalls = true
      var pauseMemoryUntil = 0
      var probeDelay = 0
      var probeHook: (Int, Int) => Unit = (_, _) => ()
      def initial(address: Int): Int = (address * 13 + 7) & 255
      def memByte(address: Int): Int = memory.getOrElse(address, initial(address))
      def expByte(address: Int): Int = expected.getOrElse(address, initial(address))
      def bytes(value: BigInt, count: Int = 8): Vector[Int] =
        (0 until count).map(i => ((value >> (8*i)) & 255).toInt).toVector
      def word(values: Seq[Int]): BigInt = values.zipWithIndex.foldLeft(BigInt(0)) {
        case (v, (b, i)) => v | (BigInt(b) << (8*i))
      }
      def bool(signal: Bool): Boolean = signal.peek().litToBoolean
      def int(signal: UInt): Int = signal.peek().litValue.toInt
      def allow: Boolean = !randomStalls || random.nextInt(4) != 0
      def core(source: Int): Int = if (source < 4) 0 else 1
      def block(address: Int): Int = address & -coherenceBytes

      dut.in.a.valid.poke(false.B)
      dut.in.c.valid.poke(false.B)
      dut.in.e.valid.poke(false.B)
      dut.in.b.ready.poke(false.B)
      dut.in.d.ready.poke(false.B)
      dut.out.a.ready.poke(false.B)
      dut.out.d.valid.poke(false.B)
      // Default every input payload before reset (including empty BundleMaps).
      dut.in.a.bits.opcode.poke(0.U); dut.in.a.bits.param.poke(0.U)
      dut.in.a.bits.size.poke(0.U); dut.in.a.bits.source.poke(0.U)
      dut.in.a.bits.address.poke(0.U); dut.in.a.bits.mask.poke(0.U)
      dut.in.a.bits.data.poke(0.U); dut.in.a.bits.corrupt.poke(false.B)
      dut.in.c.bits.opcode.poke(0.U); dut.in.c.bits.param.poke(0.U)
      dut.in.c.bits.size.poke(0.U); dut.in.c.bits.source.poke(0.U)
      dut.in.c.bits.address.poke(0.U); dut.in.c.bits.data.poke(0.U)
      dut.in.c.bits.corrupt.poke(false.B); dut.in.e.bits.sink.poke(0.U)
      dut.out.d.bits.opcode.poke(0.U); dut.out.d.bits.param.poke(0.U)
      dut.out.d.bits.size.poke(0.U); dut.out.d.bits.source.poke(0.U)
      dut.out.d.bits.sink.poke(0.U); dut.out.d.bits.data.poke(0.U)
      dut.out.d.bits.denied.poke(false.B); dut.out.d.bits.corrupt.poke(false.B)
      dut.reset.poke(true.B); dut.clock.step(5); dut.reset.poke(false.B)

      def tick(): Unit = {
        assert(cycle < 30000, s"simulation timeout, pending=$pending releases=$releases")
        dut.in.b.ready.poke(allow.B)
        dut.in.d.ready.poke(allow.B)
        dut.out.a.ready.poke((cycle >= pauseMemoryUntil && allow).B)
        dut.in.a.valid.poke(aQueue.nonEmpty.B)
        aQueue.headOption.foreach { a =>
          dut.in.a.bits.opcode.poke(a.op.U); dut.in.a.bits.param.poke(a.param.U)
          dut.in.a.bits.size.poke(a.size.U); dut.in.a.bits.source.poke(a.source.U)
          dut.in.a.bits.address.poke(a.address.U); dut.in.a.bits.mask.poke(a.mask.U)
          dut.in.a.bits.data.poke(a.data.U)
        }
        val cValid = cQueue.headOption.exists(_.due <= cycle)
        dut.in.c.valid.poke(cValid.B)
        cQueue.headOption.foreach { c =>
          dut.in.c.bits.opcode.poke(c.op.U); dut.in.c.bits.param.poke(c.param.U)
          dut.in.c.bits.size.poke(lgCoherence.U); dut.in.c.bits.source.poke(c.source.U)
          dut.in.c.bits.address.poke(c.address.U); dut.in.c.bits.data.poke(c.data.U)
        }
        val eValid = eQueue.headOption.exists(_._2 <= cycle)
        dut.in.e.valid.poke(eValid.B)
        eQueue.headOption.foreach { e => dut.in.e.bits.sink.poke(e._1.U) }
        val dValid = dQueue.headOption.exists(_.due <= cycle)
        dut.out.d.valid.poke(dValid.B)
        dQueue.headOption.foreach { d =>
          dut.out.d.bits.opcode.poke(d.op.U); dut.out.d.bits.size.poke(d.size.U)
          dut.out.d.bits.source.poke(d.source.U); dut.out.d.bits.data.poke(d.data.U)
        }

        if (aQueue.nonEmpty && bool(dut.in.a.ready)) aQueue.dequeue()
        if (cValid && bool(dut.in.c.ready)) cQueue.dequeue()
        if (eValid && bool(dut.in.e.ready)) { eQueue.dequeue(); grantAckCount += 1 }
        if (dValid && bool(dut.out.d.ready)) dQueue.dequeue()

        if (bool(dut.out.a.valid) && bool(dut.out.a.ready)) {
          val a = dut.out.a.bits
          val op = int(a.opcode); val address = int(a.address)
          val size = int(a.size); val source = int(a.source)
          assert(size == 6 && (address & 63) == 0,
            s"outer operation must cover one aligned 64B line: op=$op addr=$address size=$size")
          assert(op == 4 || op == 0, s"unexpected memory opcode $op")
          if (op == 4) {
            memoryOps += MemoryOp(op, address, size)
            (0 until 8).foreach { beat =>
              dQueue.enqueue(D(1, size, source,
                word((0 until 8).map(i => memByte(address + beat*8 + i))),
                cycle + 15 + beat*2 + random.nextInt(2)))
            }
          } else {
            val beat = putBeat.getOrElse(source, 0)
            if (beat == 0) memoryOps += MemoryOp(op, address, size)
            assert(int(a.mask) == 255, "whole-line outer writeback must preserve every byte")
            bytes(a.data.peek().litValue).zipWithIndex.foreach { case (b, i) =>
              memory(address + beat*8 + i) = b
            }
            if (beat == 7) {
              putBeat.remove(source)
              dQueue.enqueue(D(0, size, source, 0, cycle + 5))
            } else putBeat(source) = beat + 1
          }
        }
        if (bool(dut.in.b.valid) && bool(dut.in.b.ready)) {
          val b = dut.in.b.bits
          val address = int(b.address); val source = int(b.source); val cap = int(b.param)
          assert(int(b.opcode) == 6 && int(b.size) == lgCoherence)
          assert(address == block(address), s"unaligned inner probe $address")
          probes += ((core(source), address))
          probeHook(core(source), address)
          val old = held.get((core(source), address))
          val permission = old.map(_.permission).getOrElse(2)
          val next = math.max(permission, cap)
          val report = (permission, next) match {
            case (0, 0) => 3; case (0, 1) => 0; case (0, 2) => 1
            case (1, 1) => 4; case (1, 2) => 2; case (2, 2) => 5
          }
          val dirty = old.exists(_.dirty)
          val data = if (dirty) old.get.data.toVector else Vector.empty
          val beats = if (dirty) coherenceBytes/8 else 1
          (0 until beats).foreach { beat =>
            cQueue.enqueue(C(if (dirty) 5 else 4, report, source, address,
              if (dirty) word(data.slice(beat*8, beat*8+8)) else BigInt(0),
              beat == beats-1, cycle + 2 + probeDelay + beat))
          }
          old.foreach { h => h.permission = next; h.dirty = false }
          if (next == 2) held.remove((core(source), address))
        }
        if (bool(dut.in.d.valid) && bool(dut.in.d.ready)) {
          val d = dut.in.d.bits
          val op = int(d.opcode); val source = int(d.source); val size = int(d.size)
          assert(!bool(d.denied) && !bool(d.corrupt))
          if (op == 6) {
            assert(releases.remove(source), s"unexpected or duplicate ReleaseAck source $source")
            assert(size == lgCoherence); releaseCount += 1
          } else {
            val req = pending.getOrElse(source, fail(s"unexpected D source $source opcode $op"))
            assert(size == req.size)
            if (op == 5 || op == 1) req.data ++= bytes(d.data.peek().litValue)
            val count = if (op == 5 || op == 1) (1 << size) max 8 else 0
            if (req.data.length >= count) {
              if (op == 4 || op == 5) {
                assert(size == lgCoherence)
                val key = (core(source), req.address)
                val data = if (op == 5) req.data.toArray else held(key).data
                if (op == 5) assert(data.toVector == (0 until coherenceBytes).map(i => expByte(req.address+i)).toVector,
                  s"GrantData mismatch source=$source address=0x${req.address.toHexString}: ${data.toVector}")
                val granted = int(d.param)
                val otherOwners = held.iterator.filter { case ((owner, address), _) =>
                  owner != core(source) && address == req.address
                }.map(_._2.permission).toVector
                assert(!otherOwners.exists(_ == 0), "Grant raced an unresolved trunk owner")
                assert(granted != 0 || otherOwners.isEmpty, "trunk Grant left another client permission")
                held(key) = Held(granted, data, false)
                eQueue.enqueue((int(d.sink), cycle + 2 + random.nextInt(5)))
                grantCount += 1
              }
              results(source) = req.data.toVector
              pending.remove(source)
            }
          }
        }
        dut.clock.step(); cycle += 1
      }
      def waitFor(condition: => Boolean, description: String): Unit = {
        val deadline = cycle + 5000
        while (!condition && cycle < deadline) tick()
        assert(condition, s"timeout: $description at cycle $cycle; pending=$pending releases=$releases")
      }
      def drain(): Unit = {
        waitFor(pending.isEmpty && releases.isEmpty && aQueue.isEmpty && cQueue.isEmpty &&
          eQueue.isEmpty && dQueue.isEmpty, "drain all transaction acknowledgements")
        (0 until 20).foreach(_ => tick())
      }
      def acquire(coreId: Int, address: Int, write: Boolean = false, wait: Boolean = true): Unit = {
        val source = coreId*4
        assert(!pending.contains(source))
        val key = (coreId, address)
        val previous = held.get(key).map(_.permission).getOrElse(2)
        assert(previous != 0, s"client already owns trunk at $address")
        val upgrade = previous == 1 && write
        val op = if (upgrade) 7 else 6
        val grow = if (upgrade) 2 else if (write) 1 else 0
        pending(source) = Request(op, address, lgCoherence, mutable.ArrayBuffer.empty)
        results.remove(source)
        aQueue.enqueue(A(op, grow, lgCoherence, source, address))
        if (wait) { waitFor(!pending.contains(source), "Acquire completes"); drain() }
      }
      def write(coreId: Int, address: Int, seed: Int): Unit = {
        val h = held((coreId, address))
        assert(h.permission == 0, "writes require trunk permission")
        h.data.indices.foreach { i => h.data(i) = (seed + i*7) & 255; expected(address+i) = h.data(i) }
        h.dirty = true
      }
      def release(coreId: Int, address: Int, wait: Boolean = true): Unit = {
        val h = held.remove((coreId, address)).get
        val source = coreId*4+1
        releases += source
        val report = if (h.permission == 0) 1 else 2
        val beats = if (h.dirty) coherenceBytes/8 else 1
        (0 until beats).foreach { beat => cQueue.enqueue(C(if (h.dirty) 7 else 6,
          report, source, address, if (h.dirty) word(h.data.slice(beat*8, beat*8+8).toVector) else BigInt(0),
          beat == beats-1, cycle + beat)) }
        if (wait) { waitFor(!releases(source), "ReleaseAck completes"); drain() }
      }
      def get(address: Int, size: Int = 3): Vector[Int] = {
        pending(8) = Request(4, address, size, mutable.ArrayBuffer.empty)
        val mask = if (size >= 3) 255 else ((1 << (1 << size)) - 1) << (address & 7)
        aQueue.enqueue(A(4, 0, size, 8, address, mask = mask))
        waitFor(!pending.contains(8), "uncached Get completes")
        drain()
        val beat = results(8)
        val result = if (size < 3) beat.slice(address & 7, (address & 7) + (1 << size)) else beat
        assert(result == (0 until (1 << size)).map(i => expByte(address+i)).toVector,
          s"uncached Get mismatch at 0x${address.toHexString}: $result")
        result
      }

      // Directory reset, then a single 16B (or regression 64B) read miss.
      (0 until 10).foreach(_ => tick())
      val base = 0x1000
      acquire(0, base)
      assert(memoryOps.count(x => x.op == 4 && x.address == base) == 1)
      if (coherenceBytes < 64) {
        // One physical tag serves every sub-block, including different clients.
        (1 until 64/coherenceBytes).foreach(i => acquire(i & 1, base+i*coherenceBytes))
        assert(memoryOps.count(x => x.op == 4 && x.address == base) == 1)
        assert(probes.isEmpty, s"different sub-block readers caused probes: $probes")
        // Independent writers must not probe unrelated permissions.
        if (held((0, base)).permission != 0) acquire(0, base, write = true)
        if (held((1, base+coherenceBytes)).permission != 0) acquire(1, base+coherenceBytes, write = true)
        write(0, base, 0x21); write(1, base+coherenceBytes, 0x67)
        assert(probes.isEmpty, s"different sub-block writers caused probes: $probes")
        release(0, base)
        assert(memoryOps.forall(_.op != 0), "16B ReleaseData became an immediate outer writeback")
        acquire(1, base, write = true)
        write(1, base, 0x98)
      } else {
        if (held((0, base)).permission != 0) acquire(0, base, write = true)
        write(0, base, 0x21)
        release(0, base)
        acquire(1, base, write = true)
        write(1, base, 0x98)
      }
      // Same-sub-block contention transfers dirty bytes and revokes the owner.
      val beforeContention = probes.size
      acquire(0, base, write = true)
      assert(probes.drop(beforeContention).contains((1, base)))
      write(0, base, 0xb1)
      // Force a shared Branch state, then explicitly exercise AcquirePerm BtoT.
      acquire(1, base)
      assert(held((0, base)).permission == 1 && held((1, base)).permission == 1)
      acquire(0, base, write = true)
      assert(results(0).isEmpty, "AcquirePerm upgrade must return Grant without data")
      write(0, base, 0xb2)
      // Two absent-line requests queued before memory responds must share one refill.
      val concurrent = 0x1040
      pauseMemoryUntil = cycle + 30
      acquire(0, concurrent, wait = false)
      acquire(1, concurrent + (if (coherenceBytes < 64) 2*coherenceBytes else 0), wait = false)
      waitFor(pending.isEmpty, "two concurrent acquisitions"); drain()
      assert(memoryOps.count(x => x.op == 4 && x.address == concurrent) == 1,
        "coalesced requests duplicated the outer refill")
      // Recall multiple dirty owners and merge their independently returned data.
      // Delayed ProbeAcks keep the replacement transaction live under backpressure.
      probeDelay = 11
      (1 to 12).foreach { i => get(base + i*128) }
      drain()
      assert(probes.exists(_._2 == base), "replacement did not recall dirty original data")
      assert(memoryOps.exists(x => x.op == 0 && x.address == base), "dirty physical line was never written back")
      (0 until 64).foreach(i => assert(memByte(base+i) == expByte(base+i),
        s"dirty-data merge lost byte ${base+i}: ${memByte(base+i)} != ${expByte(base+i)}"))
      get(base, lgCoherence)
      if (coherenceBytes < 64) {
        // Test both a Release of the currently probed dirty sub-block and a
        // Release of a later sub-block while replacement is waiting on the first.
        def replacementRace(racing: Int, releaseFuture: Boolean): Unit = {
          acquire(0, racing, write = true)
          acquire(1, racing+coherenceBytes, write = true)
          write(0, racing, 0x39); write(1, racing+coherenceBytes, 0xe0)
          var raced = false
          probeHook = (owner, address) => {
            if (!raced && owner == 0 && address == racing) {
              raced = true
              if (releaseFuture) release(1, racing+coherenceBytes, wait = false)
              else release(0, racing, wait = false)
              acquire(1, racing+2*coherenceBytes, wait = false)
            }
          }
          (1 to 12).foreach { i => get(racing + i*128) }
          drain()
          assert(raced, "replacement did not exercise nested Release/Probe/Acquire overlap")
          (0 until 64).foreach(i => assert(memByte(racing+i) == expByte(racing+i),
            s"nested Release lost dirty byte ${racing+i}"))
          probeHook = (_, _) => ()
          get(racing, lgCoherence)
        }
        replacementRace(0x3000, releaseFuture = false)
        replacementRace(0x4000, releaseFuture = true)
      }
      // Atomic operation exercises the existing SourceD read/modify/write path.
      val atomicAddress = 0x2040
      val beforeAtomic = word(get(atomicAddress))
      pending(8) = Request(2, atomicAddress, 3, mutable.ArrayBuffer.empty)
      aQueue.enqueue(A(2, 4, 3, 8, atomicAddress, 5)) // ArithmeticData.ADD
      waitFor(!pending.contains(8), "atomic ADD completes"); drain()
      assert(word(results(8)) == beforeAtomic, "AMO did not return the previous value")
      bytes((beforeAtomic+5) & ((BigInt(1)<<64)-1)).zipWithIndex.foreach {
        case (b, i) => expected(atomicAddress+i) = b
      }
      get(atomicAddress)
      // A two-byte masked update within a beat must preserve neighboring bytes
      // and neighboring coherent sub-blocks in the same physical allocation.
      pending(8) = Request(1, atomicAddress+2, 1, mutable.ArrayBuffer.empty)
      aQueue.enqueue(A(1, 0, 1, 8, atomicAddress+2, BigInt(0xabcd) << 16, mask = 0x0c))
      waitFor(!pending.contains(8), "partial Put completes"); drain()
      expected(atomicAddress+2) = 0xcd; expected(atomicAddress+3) = 0xab
      get(atomicAddress)
      assert(get(atomicAddress+2, size = 1) == Vector(0xcd, 0xab))
      get(atomicAddress+coherenceBytes)
      assert(grantAckCount == grantCount, "GrantAck accounting mismatch")
      assert(releaseCount > 0, "ReleaseAck was not exercised")
      assert(putBeat.isEmpty && pending.isEmpty && releases.isEmpty)
      println(s"L2 test coherence=$coherenceBytes: $cycle cycles, ${memoryOps.count(_.op==4)} refills, " +
        s"${memoryOps.count(_.op==0)} writebacks, ${probes.size} probes, $grantAckCount GrantAcks, $releaseCount ReleaseAcks")
    }
  }

  behavior of "Sub-blocked InclusiveCache"
  it should "validate independent physical-line and coherence sizes" in {
    def cache(sub: Option[Int], beat: Int = 8) = CacheParameters(
      level = 2, ways = 2, sets = 2, blockBytes = 64, beatBytes = beat,
      hintsSkipProbe = false, subBlockBytes = sub)
    val split = cache(Some(16))
    assert(split.coherenceBytes == 16 && split.nSubBlocks == 4)
    assert(split.sizeBytes == 256 && split.blockBeats == 8)
    assert(cache(None).coherenceBytes == 64 && cache(None).nSubBlocks == 1)
    assert(cache(Some(64)).nSubBlocks == 1)
    Seq(0, 3, 24, 128).foreach { sub =>
      intercept[IllegalArgumentException] { cache(Some(sub)) }
    }
    intercept[IllegalArgumentException] { cache(Some(16), beat = 32) }
  }
  it should "preserve independent 16B coherence, coalesce refills, and merge dirty eviction data under backpressure" in {
    exercise(16)
  }
  it should "preserve equal-size 64B coherence behavior under backpressure" in {
    exercise(64)
  }
}
