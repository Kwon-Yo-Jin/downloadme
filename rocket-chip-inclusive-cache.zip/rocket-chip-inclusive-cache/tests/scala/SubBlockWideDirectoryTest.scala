package rocketnoc.test

import chisel3._
import chisel3.experimental.UnlocatableSourceInfo
import chisel3.util._
import chiseltest._
import chiseltest.simulator.VerilatorFlags
import org.chipsalliance.cde.config.Parameters
import org.scalatest.flatspec.AnyFlatSpec
import freechips.rocketchip.diplomacy._
import freechips.rocketchip.tilelink._
import sifive.blocks.inclusivecache._
import scala.collection.mutable

/** Exercises the real directory SRAM and probe source with 128 coherent clients.
  * No processor instances or alternate directory implementation are involved.
  */
class SubBlockWideDirectoryHarness(params: InclusiveCacheParameters) extends Module {
  val io = IO(new Bundle {
    val write = Flipped(Decoupled(new DirectoryWrite(params)))
    val read = Flipped(Valid(new DirectoryRead(params)))
    val result = Valid(new DirectoryResult(params))
    val ready = Output(Bool())
    val source = Input(UInt(params.inner.bundle.sourceBits.W))
    val selected = Input(UInt(params.clientBits.W))
    val decoded = Output(UInt(params.clientBits.W))
    val encoded = Output(UInt(params.inner.bundle.sourceBits.W))
    val probe = Flipped(Decoupled(new SourceBRequest(params)))
    val b = Decoupled(new TLBundleB(params.inner.bundle))
  })
  val directory = Module(new Directory(params))
  directory.io.write <> io.write
  directory.io.read <> io.read
  io.result <> directory.io.result
  io.ready := directory.io.ready
  io.decoded := params.clientBit(io.source)
  io.encoded := params.clientSource(io.selected)
  val sourceB = Module(new SourceB(params))
  sourceB.io.req <> io.probe
  io.b <> sourceB.io.b
}

class SubBlockWideDirectoryTest extends AnyFlatSpec with ChiselScalatestTester {
  private case class Sub(state: Int, clients: BigInt, dirty: Boolean = false)
  private case class Entry(tag: Int, subBlocks: Vector[Sub], valid: Boolean = true)
  private case class Expected(hit: Boolean, way: Int, entry: Entry)

  private def parameters(registered: Boolean)(implicit p: Parameters): InclusiveCacheParameters = {
    val clients = TLClientPortParameters((0 until 128).map { client =>
      TLClientParameters(name = s"directory-client-$client", sourceId = IdRange(client, client+1),
        supportsProbe = TransferSizes(16, 16))
    })
    def manager(bytes: Int) = TLManagerPortParameters(Seq(TLManagerParameters(
      address = Seq(AddressSet(0, 0x1fffff)), regionType = RegionType.UNCACHED,
      supportsGet = TransferSizes(1, bytes), supportsPutFull = TransferSizes(1, bytes),
      supportsAcquireB = TransferSizes(bytes, bytes),
      supportsAcquireT = TransferSizes(bytes, bytes))), beatBytes = 8, endSinkId = 4)
    val outerClient = TLClientPortParameters(Seq(TLClientParameters(
      name = "directory-outer", sourceId = IdRange(0, 2), supportsProbe = TransferSizes(64, 64))))
    InclusiveCacheParameters(
      CacheParameters(level = 2, ways = 4, sets = 8, blockBytes = 64, beatBytes = 8,
        hintsSkipProbe = false, subBlockBytes = Some(16)),
      InclusiveCacheMicroParameters(writeBytes = 8, memCycles = 8, dirReg = registered),
      control = false,
      new TLEdgeIn(clients, manager(16), p, UnlocatableSourceInfo),
      new TLEdgeOut(outerClient, manager(64), p, UnlocatableSourceInfo))
  }

  private def exercise(registered: Boolean): Unit = {
    implicit val p: Parameters = Parameters.empty
    val params = parameters(registered)
    assert(params.clientBits == 128 && params.tagBits == 12 && params.cache.nSubBlocks == 4)
    test(new SubBlockWideDirectoryHarness(params)).withAnnotations(Seq(
      VerilatorBackendAnnotation, VerilatorFlags(Seq("-Wno-fatal")))) { dut =>
      dut.clock.setTimeout(1000)
      assert(dut.io.write.bits.data.getWidth == 537,
        "this regression must exercise the 537-bit directory entry that failed at 128 clients")
      def bits(indices: Int*): BigInt = indices.foldLeft(BigInt(0))((value, i) => value.setBit(i))
      val even = (0 until 128 by 2).foldLeft(BigInt(0))((value, i) => value.setBit(i))
      val odd = ((BigInt(1) << 128) - 1) ^ even
      val empty = Entry(0, Vector.fill(4)(Sub(0, 0)), valid = false)
      val first = Entry(0xc35, Vector(
        Sub(2, bits(127), dirty = true),
        Sub(3, bits(31, 32, 63, 64)),
        Sub(3, bits(0, 64, 127), dirty = true),
        Sub(1, bits(63, 127))))
      val second = Entry(0x926, Vector(
        Sub(3, even), Sub(3, odd, dirty = true),
        Sub(2, bits(64), dirty = true), Sub(1, bits(0, 63, 127))))
      val replacement = Entry(0xfaa, Vector(
        Sub(2, bits(63)), Sub(2, bits(64), dirty = true),
        Sub(2, bits(127), dirty = true), Sub(3, bits(31, 32, 63, 64, 127))))
      val alternateSet = Entry(0x881, second.subBlocks.reverse)

      def pokeEntry(entry: Entry): Unit = {
        dut.io.write.bits.data.tag.poke(entry.tag.U)
        dut.io.write.bits.data.valid.poke(entry.valid.B)
        entry.subBlocks.zipWithIndex.foreach { case (sub, i) =>
          dut.io.write.bits.data.subBlocks(i).state.poke(sub.state.U)
          dut.io.write.bits.data.subBlocks(i).dirty.poke(sub.dirty.B)
          dut.io.write.bits.data.subBlocks(i).clients.poke(sub.clients.U)
        }
      }
      dut.io.write.valid.poke(false.B)
      dut.io.write.bits.set.poke(0.U); dut.io.write.bits.way.poke(0.U); pokeEntry(empty)
      dut.io.read.valid.poke(false.B); dut.io.read.bits.set.poke(0.U); dut.io.read.bits.tag.poke(0.U)
      dut.io.source.poke(0.U); dut.io.selected.poke(0.U)
      dut.io.probe.valid.poke(false.B); dut.io.probe.bits.clients.poke(0.U)
      dut.io.probe.bits.param.poke(2.U); dut.io.probe.bits.tag.poke(0.U)
      dut.io.probe.bits.set.poke(0.U); dut.io.probe.bits.offset.poke(0.U)
      dut.io.b.ready.poke(false.B)
      dut.reset.poke(true.B); dut.clock.step(3); dut.reset.poke(false.B)
      var resetCycles = 0
      while (!dut.io.ready.peek().litToBoolean && resetCycles < 20) {
        dut.clock.step(); resetCycles += 1
      }
      dut.io.ready.expect(true.B)

      var cycle = 0
      val pending = mutable.Queue.empty[(Int, Expected)]
      val latency = if (registered) 2 else 1
      def verify(expected: Expected): Unit = {
        dut.io.result.bits.hit.expect(expected.hit.B)
        if (expected.hit) {
          dut.io.result.bits.way.expect(expected.way.U)
          dut.io.result.bits.valid.expect(expected.entry.valid.B)
          dut.io.result.bits.tag.expect(expected.entry.tag.U)
          expected.entry.subBlocks.zipWithIndex.foreach { case (sub, i) =>
            dut.io.result.bits.subBlocks(i).state.expect(sub.state.U)
            dut.io.result.bits.subBlocks(i).dirty.expect(sub.dirty.B)
            dut.io.result.bits.subBlocks(i).clients.expect(sub.clients.U)
          }
        }
      }
      def tick(read: Option[(Int, Int, Expected)] = None,
               write: Option[(Int, Int, Entry)] = None): Unit = {
        dut.io.read.valid.poke(read.nonEmpty.B)
        read.foreach { case (set, tag, expected) =>
          dut.io.read.bits.set.poke(set.U); dut.io.read.bits.tag.poke(tag.U)
          pending.enqueue((cycle + latency, expected))
        }
        dut.io.write.valid.poke(write.nonEmpty.B)
        write.foreach { case (set, way, entry) =>
          dut.io.write.ready.expect(true.B)
          dut.io.write.bits.set.poke(set.U); dut.io.write.bits.way.poke(way.U); pokeEntry(entry)
        }
        dut.clock.step(); cycle += 1
        val resultDue = pending.headOption.exists(_._1 == cycle)
        dut.io.result.valid.expect(resultDue.B)
        if (resultDue) verify(pending.dequeue()._2)
      }
      def read(set: Int, way: Int, entry: Entry): Unit = {
        tick(Some((set, entry.tag, Expected(hit = true, way, entry))))
        (0 until latency).foreach(_ => tick())
      }
      def miss(set: Int, tag: Int): Unit = {
        tick(Some((set, tag, Expected(hit = false, 0, empty))))
        (0 until latency).foreach(_ => tick())
      }
      def write(set: Int, way: Int, entry: Entry): Unit = {
        tick(write = Some((set, way, entry))); tick()
      }

      // Reset wipes every physical way, regardless of entry width.
      (0 until 8).foreach(set => miss(set, first.tag))
      write(0, 0, first); write(0, 1, second); write(1, 0, alternateSet)
      read(0, 0, first); read(0, 1, second); read(1, 0, alternateSet)
      miss(1, first.tag)

      // Same-cycle write/read must forward all 537 bits, including the high tag
      // and the high sharers in every sub-block, before the SRAM can be updated.
      tick(Some((0, replacement.tag, Expected(hit = true, 0, replacement))),
        Some((0, 0, replacement)))
      (0 until latency).foreach(_ => tick())
      miss(0, first.tag)
      read(0, 0, replacement); read(0, 1, second); read(1, 0, alternateSet)

      // Continuous reads prevent the queued write from reaching the single-port
      // SRAM. All responses must use its full-width bypass until reads stop.
      val queued = first.copy(tag = 0xd73, subBlocks = first.subBlocks.reverse)
      tick(Some((0, queued.tag, Expected(hit = true, 2, queued))), Some((0, 2, queued)))
      (0 until 4).foreach { _ =>
        dut.io.write.ready.expect(false.B)
        tick(Some((0, queued.tag, Expected(hit = true, 2, queued))))
      }
      (0 until latency + 1).foreach(_ => tick())
      read(0, 2, queued)
      read(0, 0, replacement); read(0, 1, second)

      // A queued invalidation must suppress the stale matching SRAM way. Other
      // ways and sets must retain their tags, states and 128-bit client masks.
      val invalidated = empty.copy(tag = replacement.tag)
      tick(Some((0, replacement.tag, Expected(hit = false, 0, empty))),
        Some((0, 0, invalidated)))
      (0 until latency).foreach(_ => tick())
      miss(0, replacement.tag)
      read(0, 1, second); read(0, 2, queued); read(1, 0, alternateSet)
      assert(pending.isEmpty)

      // Validate the actual source<->directory-bit conversions across every bit,
      // including the host Int/Long boundaries and client 127.
      (0 until 128).foreach { client =>
        val oneHot = BigInt(1) << client
        dut.io.source.poke(client.U); dut.io.selected.poke(oneHot.U)
        dut.io.decoded.expect(oneHot.U); dut.io.encoded.expect(client.U)
      }

      // Drive the actual SourceB with upper sharers. It must emit one correctly
      // addressed 16B Probe per client and preserve it while backpressured.
      val targets = Vector(31, 32, 63, 64, 127)
      val probeTag = 0xe32
      val probeSet = 5
      val probeOffset = 48
      val probeAddress = (probeTag << (params.setBits + 6)) | (probeSet << 6) | probeOffset
      dut.io.probe.bits.tag.poke(probeTag.U); dut.io.probe.bits.set.poke(probeSet.U)
      dut.io.probe.bits.offset.poke(probeOffset.U); dut.io.probe.bits.clients.poke(bits(targets: _*).U)
      dut.io.probe.valid.poke(true.B); dut.io.b.ready.poke(false.B)
      dut.io.probe.ready.expect(true.B)
      dut.clock.step(); dut.io.probe.valid.poke(false.B)
      var sent = 0
      var probeCycles = 0
      while (sent < targets.size && probeCycles < 30) {
        val ready = probeCycles >= 3 && probeCycles % 3 != 0
        dut.io.b.ready.poke(ready.B)
        dut.io.b.valid.expect(true.B)
        dut.io.b.bits.source.expect(targets(sent).U)
        dut.io.b.bits.address.expect(probeAddress.U)
        dut.io.b.bits.opcode.expect(6.U); dut.io.b.bits.param.expect(2.U)
        dut.io.b.bits.size.expect(4.U); dut.io.b.bits.mask.expect(255.U)
        dut.io.b.bits.corrupt.expect(false.B)
        if (ready) sent += 1
        dut.clock.step(); probeCycles += 1
      }
      assert(sent == targets.size)
      dut.io.b.valid.expect(false.B)
      dut.io.probe.ready.expect(true.B)
      println(s"537-bit Directory, 128 clients, dirReg=$registered: ${cycle + probeCycles} checked cycles")
    }
  }

  behavior of "Sub-blocked InclusiveCache wide directory"
  Seq(false, true).foreach { registered =>
    it should s"preserve 537-bit entries and 128-client probes with dirReg=$registered" in {
      exercise(registered)
    }
  }
}
