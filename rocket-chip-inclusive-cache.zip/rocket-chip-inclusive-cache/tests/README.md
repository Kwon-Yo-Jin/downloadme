# Focused InclusiveCache tests

Run from the containing Rocket Chip repository:

```sh
rocket-chip-inclusive-cache/tests/run-tests.sh
```

The runner adds `tests/scala` to the enclosing sbt build for that invocation. It
requires that build's Chisel 6.7, chiseltest 6.0, ScalaTest, and Verilator. It does
not edit its source directories or test-selection settings permanently. To run
only the split-line hardware scenario:

```sh
rocket-chip-inclusive-cache/tests/run-tests.sh -- -z 'independent 16B'
```

`SubBlockCacheTest` instantiates the real InclusiveCache scheduler, directory,
MSHRs and data array, connected through the real TLCacheCork to a byte-addressed
software memory responder. Two synthetic coherent clients retain permission,
clean/dirty data and outstanding transactions independently. Diplomacy's TileLink
monitors remain enabled. Both links have eight-byte beats, exercising two-beat
16-byte inner transfers and eight-beat 64-byte outer transfers.

The suite checks parameter rejection, first refill and all sub-block hits,
independent client ownership and writes, same-sub-block contention, dirty release,
shared refill for concurrent misses, whole-line replacement and dirty-byte
merging, delayed ProbeAcks with overlapping Release traffic, randomized
backpressure, GrantAck/ReleaseAck accounting, explicit AcquirePerm upgrades,
partial-byte Put/Get masks, and an atomic ADD. Deterministic replacement races
release either the currently probed dirty sub-block or a later sub-block while
also acquiring a different sub-block of the victim. The same hardware
scenario also runs with equal 64-byte coherence and physical lines. Every outer
operation must be an aligned 64-byte Get or PutFull, and the byte scoreboard
checks returned data and merged memory writebacks.

`SubBlockWideDirectoryTest` simulates the actual Directory SRAM and SourceB
with 128 coherent clients and four sub-blocks per physical line. Its directory
entry is exactly 537 bits. Both `dirReg=false` and `dirReg=true` preserve full
metadata through SRAM reads, same-cycle writes, queued-write bypass and
invalidation, while isolating different ways and sets. The test exercises client
bits 31, 32, 63, 64 and 127, alternating 128-bit sharer masks, every source-to-bit
mapping, and upper-client Probe fanout under backpressure.

`SubBlockedRocketConfigSpec` additionally elaborates the standard two-core,
two-bank `ExampleRocketSystem` into CHIRRTL. It checks actual 16-byte L1I/L1D
parameters, eight-byte beats, 64-byte L2 banking and outer transfer support. It
uses the existing local boot ROM image with DTB embedding disabled. This checks
processor RTL integration; it does not execute processor instructions.

These synthetic clients do not execute Rocket instructions. In particular, the
suite does not validate Rocket LR/SC reservation behavior, software fences or
full-system boot. Those require a processor simulation. It does not model denied
memory responses or a coherent outer cache: the checked-out cache supports only
a last-level placement, and the test intentionally uses its existing CacheCork
integration. The traffic is directed with a reproducible random stall seed;
it is not an exhaustive proof of all coherence races.

## Verification on 2026-11-16

Executed from `/proj/ruche-network` against the modified checkout:

| Command | Result |
| --- | --- |
| `mill -i generator.compile` | PASS, exit 0. |
| `rocket-chip-inclusive-cache/tests/run-tests.sh` | PASS, exit 0; six tests in three suites, including four Verilator simulations and Rocket CHIRRTL elaboration. |
| `make verilog CONFIG=FPGADefaultNCoreConfig -j16` | PASS, exit 0 with `core_num = 128`; complete Chisel elaboration and firtool SystemVerilog generation. |
| `git -C rocket-chip-inclusive-cache diff --check` | PASS, exit 0. |

The 16B/64B run completed 3,258 cycles with 46 refills, three writebacks,
15 probes, 16 GrantAcks and three ReleaseAcks. The equal-64B run completed
1,378 cycles with 17 refills, one writeback, seven probes, seven GrantAcks
and one ReleaseAck. These totals include deliberate eviction traffic; per-line
assertions separately check that concurrent requests share one refill.
The 128-client directory regressions completed 74 checked cycles without the
optional directory register and 100 cycles with it. The separately generated
128-core design contains 16B L1I/L1D lines, 64B L2 lines, four sub-blocks and
537-bit directory entries; its eight-way directory SRAM has a 4,296-bit row.
This full-system build checks RTL generation, not 128-core instruction execution.

Existing Scala deprecation/feature warnings and narrow-index elaboration warnings
in Scheduler and Rocket Debug remain. No test failures remain.
