#!/usr/bin/env bash
set -euo pipefail
repo_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
cd "$repo_root"
# Keep the enclosing repository's build and its existing test source selection intact.
export MAKEFLAGS="${MAKEFLAGS:-} VM_PARALLEL_BUILDS=1 VK_PCH_I_FAST= VK_PCH_I_SLOW="
test_args=""
for test_arg in "$@"; do
  escaped_arg="${test_arg//\\/\\\\}"
  escaped_arg="${escaped_arg//\"/\\\"}"
  test_args+=" \"${escaped_arg}\""
done
sbt -sbt-version 1.10.2 -batch \
  'set Test / unmanagedSourceDirectories += baseDirectory.value / "rocket-chip-inclusive-cache" / "tests" / "scala"' \
  "testOnly rocketnoc.test.SubBlock*${test_args}"
