# Rocket Chip SoC Inclusive Cache Generator

This `block` package contains an RTL generator for creating instances of a coherent, last-level, inclusive cache.
The `InclusiveCache` controller enforces coherence among a set of caching clients
using an invalidation-based coherence policy implemetated on top of the the TileLink 1.8.1 coherence messaging protocol.
This policy is implemented using a full-map of directory bits stored with each cache block's metadata tag.

The `InclusiveCache` is a TileLink adapter;
it can be used as a drop-in replacement for Rocket-Chip's `tilelink.BroadcastHub` coherence manager.
It additionally supplies a SW-controlled interface for flusing cache blocks based on physical addresses.

The following parameters of the cache are easily `Config`-urable: 
size, ways, banking and sub-banking factors, external bandwidth, network interface buffering.

Focused simulation and Rocket integration tests are described in [tests/README.md](tests/README.md).

This repository is a replacement for https://github.com/sifive/block-inclusivecache-sifive

## Independent L1 coherence and L2 allocation sizes

`CacheParameters` accepts `subBlockBytes: Option[Int] = None`. `blockBytes`
remains the physical allocation, tag, refill and writeback size;
`coherenceBytes = subBlockBytes.getOrElse(blockBytes)` is the inner coherence
size. `nSubBlocks = blockBytes / coherenceBytes` is derived, never fixed at four.
Omitting the new parameter retains equal-size behavior.

For a standard Rocket system, compose these configuration fragments before the
core and base configuration:

```scala
new WithInclusiveCache(l2BlockBytes = Some(64)) ++
new WithCacheBlockBytes(16) ++
// WithNBigCores, bus topology and BaseConfig follow
```

The L2 fragment also sets `MemoryBusKey.blockBytes` to 64. That is necessary:
the standard topology uses the memory-bus block size for `BankBinder` interleave
and the external memory transfer limit. The system bus and `CacheBlockBytes`
remain 16. A complete two-core, two-bank example is exercised in
[SubBlockedRocketConfigSpec.scala](tests/scala/SubBlockedRocketConfigSpec.scala).
Custom topologies must likewise bank at the physical L2 line boundary.

For direct instantiation, use
`CacheParameters(..., blockBytes = 64, beatBytes = 8, subBlockBytes = Some(16))`.
Sizes must be positive powers of two; the physical line must be an integral
multiple of the coherence block. The checked-out TileLink monitors require a
coherent transfer to contain at least one beat, so inner beats must be no wider
than the coherence block. The backing-store write unit must fit both interfaces.
Each coherent client must advertise Probe support for the selected coherence
size. Directory SRAM width grows with the complete per-sub-block client masks;
it is not capped at 256 bits. For the 128-core, 512 KiB, eight-way configuration,
each entry is 537 bits (12 tag bits, one valid bit, and four 131-bit metadata
records). FPGA memory use and timing depend on synthesis and placement.

### Directory and transactions

Each physical entry stores one tag, one valid bit, and a vector of
`{state, clients, dirty}` records. All sub-block data becomes valid together after
a successful full-line refill. The original states retain their meanings:
`BRANCH` means the outer manager holds trunk permission; `TRUNK` means one inner
client holds trunk permission; `TIP` means this cache holds trunk permission and
inner clients may hold branch permission. These are hierarchical TileLink states.

The MSHR keeps the whole entry and selects one sub-block for the existing
permission-transition logic. Its final directory write merges that result with
the other records. The scheduler retains its existing physical-set lock and
secondary queues. Requests for different sub-blocks of an absent line share the
first refill, then reuse the updated whole-entry metadata. Same-set requests
remain serialized, as in the original implementation; transactions in different
sets retain the existing MSHR concurrency. A client GrantAck still holds its MSHR.

For example, a 16-byte Acquire at `0x1020` looks up the tag for `0x1000`, selects
sub-block 2, and on a miss issues one 64-byte outer Acquire at `0x1000`.
`SinkD` stores the entire line; `SourceD` returns only `0x1020..0x102f`.
An inner AcquirePerm miss also fetches the physical line, because the other
sub-blocks require valid data. A successful outer permission upgrade updates
BRANCH siblings consistently with the line-wide outer permission.

Ordinary probes affect only the selected sub-block. Eviction and flush walk all
sub-blocks with sharers, issue coherence-sized probes, and wait for every final
ProbeAckData beat before releasing the physical line. Returned data is written
at its line-relative offset. Dirty bits are ORed across the line to choose a
full-line ReleaseData. A voluntary sub-block ReleaseData updates the cache and
receives ReleaseAck without immediately writing to memory. Nested Releases
merge into the parent MSHR, preserving pending probe targets and dirty data.
Existing data-pipeline hazards protect late stores before refill or writeback.
The explicit software invalidate operation retains its original discard-data
semantics; ordinary replacement and flush preserve dirty data.

This checkout requires a last-level placement (`require(lastLevel)`). Its
existing `TLCacheCork` converts full-line Acquire/Release traffic into legal
memory Get/PutFull transactions and locally acknowledges clean releases.
A coherent outer cache remains unsupported and is rejected at elaboration.

### Source audit and modified files

| Source | Granularity and change |
| --- | --- |
| `Parameters.scala` | Keeps `offsetBits`, tag/set bits and beat indices physical-line-relative; adds coherence size, sub-block address helpers and validation. |
| `Directory.scala` | One physical tag/allocation with independent metadata records and invariant checks. |
| `InclusiveCache.scala` | Advertises coherence-sized inner Acquires and limits inner Get/Put/Hint to one sub-block; outer capability checks remain physical-line-sized. |
| `Configs.scala` | Separates L2 capacity/line size from the L1 size and sets physical-line memory banking. |
| `MSHR.scala` | Selects sub-block metadata, merges whole-entry updates, walks victim probes and aggregates dirty state. |
| `Scheduler.scala` | Retains physical set/tag coalescing, routes ProbeAcks by active tag/sub-block, and forwards nested metadata. |
| `SinkA.scala` | Checks inner request size and alignment. |
| `SinkC.scala` | Checks coherence size; maps transaction-local C beats to physical data-array offsets. |
| `SourceB.scala` | Uses coherence-sized probes at the selected sub-block address. |
| `SourceD.scala` | Retains existing offset/size-based GrantData and atomic paths; derives ReleaseData byte masks from transaction size. |
| `SourceA.scala`, `SourceC.scala`, `SinkD.scala` | Audited, unchanged: outer Acquire, Release, refill and writeback stay physical-line-sized. |
| `BankedStore.scala` | Audited, unchanged: banks use physical beat/write-unit widths and physical-line-relative addresses. |
| `QueuedRequest.scala`, `SinkE.scala`, `SourceE.scala` | Audited, unchanged: request offsets retain sub-block selection; sink/source IDs retain acknowledgement routing. |
| `tests/scala/SubBlockCacheTest.scala` | New hardware and parameter regressions. |
| `tests/scala/SubBlockedRocketConfigSpec.scala` | New two-core, two-bank Rocket integration elaboration. |
| `tests/scala/SubBlockWideDirectoryTest.scala` | 128-client, 537-bit directory storage/bypass and upper-client probe regressions, with both directory pipeline modes. |
| `tests/run-tests.sh`, `tests/README.md` | New reproducible runner, coverage notes and executed verification results. |
| `README.md` | Configuration, architecture, source audit and limitations. |

No Rocket core, ICache or DCache RTL changes are required. In this checkout,
`BaseTile.cacheBlockBytes` reads the global `CacheBlockBytes`; changing only
`ICacheParams.blockBytes` or `DCacheParams.blockBytes` is insufficient. The latter
also controls DCache Probe capabilities, so custom core configurations must keep
those fields consistent with the global 16-byte value. Standard
`WithNBigCores` does this. Instruction-level LR/SC and full-system boot remain
unverified; the unchanged DCache reservation logic uses `blockOffBits` from that
global size and clears reservations on probes. See the test notes for other
verification limits.
